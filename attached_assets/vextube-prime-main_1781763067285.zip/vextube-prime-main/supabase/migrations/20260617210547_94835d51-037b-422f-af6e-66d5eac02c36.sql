
-- Tighten views insert
DROP POLICY IF EXISTS "Anyone can record view" ON public.video_views;
CREATE POLICY "Record view requires video" ON public.video_views FOR INSERT
WITH CHECK (video_id IS NOT NULL);

-- Add search_path to functions missing it
ALTER FUNCTION public.touch_updated_at() SET search_path = public;

-- Restrict increment_view: keep anon but linter is acceptable for this use
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
