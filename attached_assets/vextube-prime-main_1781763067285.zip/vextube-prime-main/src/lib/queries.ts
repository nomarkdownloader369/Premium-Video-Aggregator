import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Video = {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  youtube_id: string;
  thumbnail_url: string | null;
  duration_seconds: number | null;
  category_id: string | null;
  status: string;
  views_count: number;
  likes_count: number;
  trending_score: number;
  is_editor_pick: boolean;
  tags: string[];
  published_at: string | null;
  created_at: string;
  submitter_id: string | null;
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  icon: string | null;
  color: string | null;
  sort_order: number;
};

export const categoriesQuery = () =>
  queryOptions({
    queryKey: ["categories"],
    queryFn: async (): Promise<Category[]> => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return (data ?? []) as Category[];
    },
  });

export const publishedVideosQuery = (opts?: {
  limit?: number;
  categoryId?: string;
  order?: "trending" | "recent" | "views";
  editorPick?: boolean;
}) =>
  queryOptions({
    queryKey: ["videos", "published", opts],
    queryFn: async (): Promise<Video[]> => {
      let q = supabase.from("videos").select("*").eq("status", "published");
      if (opts?.categoryId) q = q.eq("category_id", opts.categoryId);
      if (opts?.editorPick) q = q.eq("is_editor_pick", true);
      if (opts?.order === "recent")
        q = q.order("published_at", { ascending: false });
      else if (opts?.order === "views")
        q = q.order("views_count", { ascending: false });
      else q = q.order("trending_score", { ascending: false });
      q = q.limit(opts?.limit ?? 24);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Video[];
    },
  });

export const videoBySlugQuery = (slug: string) =>
  queryOptions({
    queryKey: ["video", slug],
    queryFn: async (): Promise<Video | null> => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return data as Video | null;
    },
  });

export const searchVideosQuery = (term: string) =>
  queryOptions({
    queryKey: ["search", term],
    queryFn: async (): Promise<Video[]> => {
      if (!term.trim()) return [];
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("status", "published")
        .ilike("title", `%${term}%`)
        .order("trending_score", { ascending: false })
        .limit(40);
      if (error) throw error;
      return (data ?? []) as Video[];
    },
  });
