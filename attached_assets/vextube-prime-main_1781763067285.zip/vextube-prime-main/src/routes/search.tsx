import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { Search as SearchIcon } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { VideoCard } from "@/components/video-card";
import { searchVideosQuery } from "@/lib/queries";

const schema = z.object({
  q: fallback(z.string(), "").default(""),
});

export const Route = createFileRoute("/search")({
  validateSearch: zodValidator(schema),
  head: () => ({
    meta: [{ title: "Search — VexTube" }],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const { data, isLoading } = useQuery(searchVideosQuery(q));
  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px]">
        <div className="flex items-center gap-3">
          <SearchIcon className="h-6 w-6 text-primary" />
          <h1 className="font-display text-3xl font-extrabold">
            {q ? `Results for "${q}"` : "Search VexTube"}
          </h1>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          {isLoading
            ? "Indexing the catalog…"
            : `${data?.length ?? 0} results found`}
        </p>
        {!q && (
          <div className="mt-12 text-center text-muted-foreground">
            Start typing in the top bar to search across millions of moments.
          </div>
        )}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
          {(data ?? []).map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </div>
    </PageShell>
  );
}
