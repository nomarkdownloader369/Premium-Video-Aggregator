import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";

const BASE_URL = "";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: { path: string; changefreq?: string; priority?: string }[] = [
          { path: "/", changefreq: "hourly", priority: "1.0" },
          { path: "/trending", changefreq: "hourly", priority: "0.9" },
          { path: "/categories", changefreq: "daily", priority: "0.8" },
          { path: "/search", changefreq: "weekly", priority: "0.4" },
        ];

        const { data: cats } = await supabase
          .from("categories")
          .select("slug");
        cats?.forEach((c) =>
          entries.push({ path: `/category/${c.slug}`, changefreq: "daily", priority: "0.7" }),
        );

        const { data: videos } = await supabase
          .from("videos")
          .select("slug")
          .eq("status", "published")
          .limit(5000);
        videos?.forEach((v) =>
          entries.push({ path: `/video/${v.slug}`, changefreq: "weekly", priority: "0.6" }),
        );

        const urls = entries
          .map(
            (e) =>
              `  <url><loc>${BASE_URL}${e.path}</loc>${
                e.changefreq ? `<changefreq>${e.changefreq}</changefreq>` : ""
              }${e.priority ? `<priority>${e.priority}</priority>` : ""}</url>`,
          )
          .join("\n");

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>`;

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
