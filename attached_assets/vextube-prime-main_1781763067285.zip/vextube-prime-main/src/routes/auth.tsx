import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [{ title: "Sign in — VexTube" }],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Welcome to VexTube");
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
      }
      navigate({ to: "/" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) toast.error("Google sign-in failed");
  };

  return (
    <PageShell noPadding>
      <div className="min-h-screen grid lg:grid-cols-2">
        <div className="relative hidden lg:block overflow-hidden">
          <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 grid place-items-center">
            <div className="max-w-md px-10 text-center">
              <div className="inline-block px-3 py-1 rounded-full glass text-xs uppercase tracking-[0.3em]">
                The future of streaming
              </div>
              <h2 className="mt-6 font-display text-5xl font-black">
                Welcome to <span className="text-gradient-red">VexTube</span>
              </h2>
              <p className="mt-4 text-muted-foreground">
                Cinematic. Personalized. Engineered for taste. Sign in to unlock
                submissions, watchlists, and creator analytics.
              </p>
            </div>
          </div>
        </div>
        <div className="grid place-items-center p-8">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm"
          >
            <Link to="/" className="font-display text-2xl font-extrabold">
              Vex<span className="text-gradient-red">Tube</span>
            </Link>
            <h1 className="mt-8 font-display text-3xl font-extrabold">
              {mode === "signin" ? "Sign in" : "Create your account"}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {mode === "signin"
                ? "Continue your cinematic journey."
                : "Join the platform creators love."}
            </p>

            <button
              onClick={google}
              type="button"
              className="mt-6 w-full h-11 rounded-full bg-white text-black font-semibold hover:bg-white/90 transition"
            >
              Continue with Google
            </button>

            <div className="my-5 flex items-center gap-2 text-xs text-muted-foreground">
              <div className="flex-1 h-px bg-white/10" /> OR{" "}
              <div className="flex-1 h-px bg-white/10" />
            </div>

            <form onSubmit={submit} className="space-y-3">
              <input
                type="email"
                required
                placeholder="you@studio.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring text-sm"
              />
              <input
                type="password"
                required
                minLength={8}
                placeholder="Password (8+ characters)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring text-sm"
              />
              <button
                disabled={loading}
                className="w-full h-11 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow disabled:opacity-60"
              >
                {loading ? "…" : mode === "signin" ? "Sign in" : "Create account"}
              </button>
            </form>

            <button
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
              className="mt-5 text-sm text-muted-foreground hover:text-foreground"
            >
              {mode === "signin"
                ? "No account? Create one"
                : "Already have an account? Sign in"}
            </button>
          </motion.div>
        </div>
      </div>
    </PageShell>
  );
}
