import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageShell } from "@/components/page-shell";
import { VideoCard } from "@/components/video-card";
import { categoriesQuery, publishedVideosQuery } from "@/lib/queries";

export const Route = createFileRoute("/category/$slug")({
  head: () => ({ meta: [{ title: "Category — VexTube" }] }),
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const cats = useQuery(categoriesQuery());
  const cat = cats.data?.find((c) => c.slug === slug);
  const videos = useQuery({
    ...publishedVideosQuery({ categoryId: cat?.id, order: "trending", limit: 60 }),
    enabled: !!cat?.id,
  });

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px]">
        <div
          className="relative overflow-hidden rounded-3xl p-10 md:p-14 border border-white/5"
          style={{
            background: cat
              ? `linear-gradient(135deg, ${cat.color ?? "#E50914"}40, transparent 70%), oklch(0.13 0 0)`
              : "oklch(0.13 0 0)",
          }}
        >
          <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
            Category
          </div>
          <h1 className="mt-2 font-display text-5xl md:text-6xl font-black">
            {cat?.name ?? "Loading…"}
          </h1>
          {cat?.description && (
            <p className="mt-3 text-muted-foreground max-w-xl">{cat.description}</p>
          )}
        </div>
        <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
          {(videos.data ?? []).map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </div>
    </PageShell>
  );
}
