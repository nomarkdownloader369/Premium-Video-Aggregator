import { createFileRoute, Link, Outlet, redirect, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Clock,
  Film,
  Download,
  BarChart3,
  Search,
  Bell,
  Activity,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/admin")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
    const { data: role } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .in("role", ["admin", "moderator"])
      .maybeSingle();
    if (!role) throw redirect({ to: "/" });
  },
  component: AdminLayout,
});

const items = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/pending", label: "Pending review", icon: Clock },
  { to: "/admin/videos", label: "Videos", icon: Film },
  { to: "/admin/import", label: "Import center", icon: Download },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/admin/seo", label: "SEO center", icon: Search },
  { to: "/admin/notifications", label: "Notifications", icon: Bell },
  { to: "/admin/system", label: "System health", icon: Activity },
];

function AdminLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="pt-20 container-px mx-auto max-w-[1600px] grid lg:grid-cols-[240px_1fr] gap-8">
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground px-3 mb-3">
            Control center
          </div>
          <nav className="space-y-1">
            {items.map((i) => {
              const active = i.exact ? pathname === i.to : pathname.startsWith(i.to);
              return (
                <Link
                  key={i.to}
                  to={i.to}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition ${
                    active
                      ? "bg-gradient-to-r from-primary/20 to-accent/10 text-foreground border border-primary/20"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  }`}
                >
                  <i.icon className="h-4 w-4" />
                  {i.label}
                </Link>
              );
            })}
          </nav>
        </aside>
        <div className="min-w-0 pb-24">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
