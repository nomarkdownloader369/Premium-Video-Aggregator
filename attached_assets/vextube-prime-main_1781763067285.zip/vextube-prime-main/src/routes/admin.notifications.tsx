import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/admin/notifications")({
  head: () => ({ meta: [{ title: "Notifications — VexTube admin" }] }),
  component: AdminNotifs,
});

function AdminNotifs() {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const { data } = useQuery({
    queryKey: ["admin-notifs"],
    queryFn: async () => {
      const { data } = await supabase
        .from("notifications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      return data ?? [];
    },
  });

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const { error } = await supabase.from("notifications").insert({
      audience: "admin",
      type: "announcement",
      title: title.trim(),
      body: body.trim() || null,
    });
    if (error) return toast.error(error.message);
    toast.success("Notification sent");
    setTitle("");
    setBody("");
    qc.invalidateQueries({ queryKey: ["admin-notifs"] });
  };

  return (
    <>
      <h1 className="font-display text-4xl font-black">Notification center</h1>
      <p className="text-muted-foreground mt-1">
        Push system alerts, moderation pings, and announcements.
      </p>

      <form onSubmit={send} className="mt-6 p-5 rounded-2xl glass grid gap-3">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title"
          className="h-11 px-4 rounded-xl bg-white/5 border border-white/10 text-sm"
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={3}
          placeholder="Body (optional)"
          className="px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm resize-none"
        />
        <button className="inline-flex items-center gap-2 self-end h-10 px-5 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow">
          <Send className="h-4 w-4" /> Send to admins
        </button>
      </form>

      <div className="mt-6 space-y-2">
        {(data ?? []).map((n) => (
          <div key={n.id} className="p-4 rounded-xl glass">
            <div className="flex items-center justify-between text-xs">
              <span className="uppercase tracking-wider text-muted-foreground">
                {n.audience} · {n.type}
              </span>
              <span className="text-muted-foreground">{timeAgo(n.created_at)}</span>
            </div>
            <div className="mt-1 font-semibold">{n.title}</div>
            {n.body && <div className="text-sm text-muted-foreground mt-1">{n.body}</div>}
          </div>
        ))}
      </div>
    </>
  );
}
