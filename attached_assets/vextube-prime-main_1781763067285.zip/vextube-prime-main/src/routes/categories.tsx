import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageShell } from "@/components/page-shell";
import { categoriesQuery } from "@/lib/queries";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [{ title: "Categories — VexTube" }],
    links: [{ rel: "canonical", href: "/categories" }],
  }),
  component: CategoriesPage,
});

function CategoriesPage() {
  const { data } = useQuery(categoriesQuery());
  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px]">
        <h1 className="font-display text-5xl md:text-6xl font-black">
          Browse <span className="text-gradient-gold">every</span> category
        </h1>
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {(data ?? []).map((c) => (
            <Link
              key={c.id}
              to="/category/$slug"
              params={{ slug: c.slug }}
              className="group relative overflow-hidden rounded-2xl p-8 border border-white/5 aspect-[5/3]"
              style={{
                background: `linear-gradient(135deg, ${c.color ?? "#E50914"}55, transparent), oklch(0.13 0 0)`,
              }}
            >
              <div className="font-display text-3xl font-extrabold">{c.name}</div>
              <p className="mt-2 text-sm text-muted-foreground max-w-xs">
                {c.description}
              </p>
              <div className="absolute right-6 bottom-6 h-14 w-14 rounded-full text-2xl font-black grid place-items-center text-white group-hover:scale-110 transition"
                   style={{ background: c.color ?? "#E50914" }}>
                {c.name[0]}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </PageShell>
  );
}
