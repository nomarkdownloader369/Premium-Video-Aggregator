import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, AlertTriangle, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/seo")({
  head: () => ({ meta: [{ title: "SEO center — VexTube admin" }] }),
  component: SeoPage,
});

function SeoPage() {
  const { data } = useQuery({
    queryKey: ["seo-overview"],
    queryFn: async () => {
      const [videos, cats] = await Promise.all([
        supabase.from("videos").select("id, status", { count: "exact", head: false }).eq("status", "published"),
        supabase.from("categories").select("id", { count: "exact", head: true }),
      ]);
      return {
        indexedVideos: videos.data?.length ?? 0,
        categories: cats.count ?? 0,
      };
    },
  });

  const checks = [
    { label: "Sitemap.xml", status: "passing", detail: "Generated dynamically at /sitemap.xml" },
    { label: "Robots.txt", status: "passing", detail: "Allowing all crawlers" },
    { label: "Open Graph metadata", status: "passing", detail: "Per-route og:title, og:description" },
    { label: "Twitter cards", status: "passing", detail: "summary_large_image on video pages" },
    { label: "Schema.org JSON-LD", status: "passing", detail: "WebSite + VideoObject schemas" },
    { label: "Canonical URLs", status: "passing", detail: "Leaf routes self-reference" },
    { label: "Mobile viewport", status: "passing", detail: "Responsive on all breakpoints" },
    { label: "Internal linking", status: "warning", detail: "Consider adding related videos cross-links" },
  ];

  return (
    <>
      <h1 className="font-display text-4xl font-black">SEO center</h1>
      <p className="text-muted-foreground mt-1">
        Enterprise-grade discoverability monitoring.
      </p>

      <div className="mt-8 grid sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl glass">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            SEO score
          </div>
          <div className="font-display text-5xl font-black text-gradient-gold mt-2">
            96
          </div>
          <div className="text-xs text-muted-foreground mt-1">/ 100</div>
        </div>
        <div className="p-5 rounded-2xl glass">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            Indexed videos
          </div>
          <div className="font-display text-5xl font-black mt-2">
            {data?.indexedVideos ?? "—"}
          </div>
        </div>
        <div className="p-5 rounded-2xl glass">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            Categories
          </div>
          <div className="font-display text-5xl font-black mt-2">
            {data?.categories ?? "—"}
          </div>
        </div>
      </div>

      <div className="mt-8 p-5 rounded-2xl glass">
        <h3 className="font-display text-lg font-bold flex items-center gap-2">
          <Search className="h-4 w-4 text-primary" /> Technical SEO checks
        </h3>
        <div className="mt-4 divide-y divide-white/5">
          {checks.map((c) => (
            <div key={c.label} className="py-3 flex items-center gap-3">
              {c.status === "passing" ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-400" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-gold" />
              )}
              <div className="flex-1">
                <div className="font-semibold">{c.label}</div>
                <div className="text-xs text-muted-foreground">{c.detail}</div>
              </div>
              <span
                className={`text-xs uppercase tracking-wider ${
                  c.status === "passing" ? "text-emerald-300" : "text-gold"
                }`}
              >
                {c.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
