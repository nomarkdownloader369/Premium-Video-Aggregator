import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, X, Trash2, Eye } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { timeAgo, youtubeThumb } from "@/lib/format";
import type { Video } from "@/lib/queries";

export const Route = createFileRoute("/admin/pending")({
  head: () => ({ meta: [{ title: "Pending review — VexTube admin" }] }),
  component: PendingPage,
});

function PendingPage() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin-pending"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Video[];
    },
  });

  const act = async (id: string, action: "approve" | "reject" | "delete") => {
    const { data: u } = await supabase.auth.getUser();
    if (action === "delete") {
      const { error } = await supabase.from("videos").delete().eq("id", id);
      if (error) return toast.error(error.message);
    } else {
      const status = action === "approve" ? "published" : "rejected";
      const { error } = await supabase
        .from("videos")
        .update({
          status,
          published_at: status === "published" ? new Date().toISOString() : null,
        })
        .eq("id", id);
      if (error) return toast.error(error.message);
    }
    await supabase.from("moderation_log").insert({
      video_id: id,
      moderator_id: u.user?.id,
      action,
    });
    toast.success(`Video ${action}d`);
    qc.invalidateQueries({ queryKey: ["admin-pending"] });
  };

  return (
    <>
      <h1 className="font-display text-4xl font-black">Pending review</h1>
      <p className="text-muted-foreground mt-1">
        {data?.length ?? 0} submissions awaiting moderation.
      </p>
      <div className="mt-8 space-y-3">
        {(data ?? []).length === 0 && (
          <div className="p-10 rounded-2xl glass text-center text-muted-foreground">
            Inbox zero. The queue is clear.
          </div>
        )}
        {(data ?? []).map((v) => (
          <div
            key={v.id}
            className="p-4 rounded-2xl glass flex flex-col sm:flex-row gap-4"
          >
            <div className="relative w-full sm:w-56 aspect-video rounded-xl overflow-hidden flex-shrink-0">
              <img
                src={v.thumbnail_url || youtubeThumb(v.youtube_id, "hq")}
                alt={v.title}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold">{v.title}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Submitted {timeAgo(v.created_at)} · YouTube {v.youtube_id}
              </div>
              {v.description && (
                <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                  {v.description}
                </p>
              )}
              <div className="mt-3 flex flex-wrap gap-2">
                <a
                  target="_blank"
                  rel="noreferrer"
                  href={`https://youtube.com/watch?v=${v.youtube_id}`}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs"
                >
                  <Eye className="h-3 w-3" /> Preview
                </a>
                <button
                  onClick={() => act(v.id, "approve")}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-xs"
                >
                  <Check className="h-3 w-3" /> Approve & publish
                </button>
                <button
                  onClick={() => act(v.id, "reject")}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gold/20 text-gold hover:bg-gold/30 text-xs"
                >
                  <X className="h-3 w-3" /> Reject
                </button>
                <button
                  onClick={() => act(v.id, "delete")}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 text-xs"
                >
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
