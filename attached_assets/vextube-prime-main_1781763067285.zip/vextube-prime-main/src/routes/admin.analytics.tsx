import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { Globe, Smartphone, Monitor, Tablet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { compactNumber } from "@/lib/format";
import type { Video } from "@/lib/queries";

export const Route = createFileRoute("/admin/analytics")({
  head: () => ({ meta: [{ title: "Analytics — VexTube admin" }] }),
  component: Analytics,
});

const COLORS = [
  "oklch(0.62 0.235 27)",
  "oklch(0.7 0.19 48)",
  "oklch(0.87 0.15 88)",
  "oklch(0.72 0.16 200)",
  "oklch(0.7 0.18 320)",
];

function Analytics() {
  const top = useQuery({
    queryKey: ["analytics-top"],
    queryFn: async () => {
      const { data } = await supabase
        .from("videos")
        .select("*")
        .eq("status", "published")
        .order("views_count", { ascending: false })
        .limit(10);
      return (data ?? []) as Video[];
    },
  });

  const series = Array.from({ length: 30 }).map((_, i) => ({
    day: i + 1,
    live: 1200 + Math.round(Math.sin(i / 3) * 400 + i * 8),
    sessions: 28000 + i * 600 + Math.round(Math.cos(i / 2) * 4000),
  }));

  const devices = [
    { name: "Mobile", value: 58 },
    { name: "Desktop", value: 34 },
    { name: "Tablet", value: 6 },
    { name: "TV", value: 2 },
  ];
  const countries = [
    { name: "United States", value: 32 },
    { name: "Brazil", value: 14 },
    { name: "India", value: 11 },
    { name: "Germany", value: 8 },
    { name: "Japan", value: 7 },
    { name: "France", value: 6 },
  ];

  return (
    <>
      <h1 className="font-display text-4xl font-black">Real-time analytics</h1>
      <p className="text-muted-foreground mt-1">Enterprise insights from the signal layer.</p>

      <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Live visitors", value: "2,418", icon: Globe },
          { label: "Mobile", value: "58%", icon: Smartphone },
          { label: "Desktop", value: "34%", icon: Monitor },
          { label: "Tablet", value: "6%", icon: Tablet },
        ].map((s) => (
          <div key={s.label} className="p-5 rounded-2xl glass flex items-center gap-3">
            <div className="h-10 w-10 rounded-full grid place-items-center bg-white/5">
              <s.icon className="h-4 w-4" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                {s.label}
              </div>
              <div className="font-display text-2xl font-extrabold">{s.value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-5 rounded-2xl glass">
        <h3 className="font-display text-lg font-bold">Live visitors & sessions (30d)</h3>
        <div className="h-72 mt-3">
          <ResponsiveContainer>
            <LineChart data={series}>
              <CartesianGrid stroke="oklch(1 0 0 / 0.05)" />
              <XAxis dataKey="day" stroke="oklch(0.6 0 0)" fontSize={11} />
              <YAxis stroke="oklch(0.6 0 0)" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "oklch(0.13 0 0)",
                  border: "1px solid oklch(1 0 0 / 0.1)",
                  borderRadius: 12,
                }}
              />
              <Line type="monotone" dataKey="live" stroke="oklch(0.62 0.235 27)" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="sessions" stroke="oklch(0.7 0.19 48)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-6 grid lg:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl glass">
          <h3 className="font-display text-lg font-bold">Top videos by views</h3>
          <ol className="mt-4 space-y-2">
            {(top.data ?? []).map((v, i) => (
              <li key={v.id} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                <span className="text-2xl font-display font-black text-gradient-red w-8">
                  {i + 1}
                </span>
                <span className="flex-1 text-sm font-medium line-clamp-1">{v.title}</span>
                <span className="text-sm font-mono text-muted-foreground">
                  {compactNumber(v.views_count)}
                </span>
              </li>
            ))}
          </ol>
        </div>
        <div className="p-5 rounded-2xl glass">
          <h3 className="font-display text-lg font-bold">Devices</h3>
          <div className="h-64 mt-3">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={devices} dataKey="value" innerRadius={50} outerRadius={90} paddingAngle={2}>
                  {devices.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="mt-6 p-5 rounded-2xl glass">
        <h3 className="font-display text-lg font-bold">Countries</h3>
        <div className="mt-4 space-y-2">
          {countries.map((c) => (
            <div key={c.name}>
              <div className="flex justify-between text-sm mb-1">
                <span>{c.name}</span>
                <span className="text-muted-foreground">{c.value}%</span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-accent"
                  style={{ width: `${c.value * 3}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
