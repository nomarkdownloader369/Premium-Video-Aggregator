import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Film,
  Eye,
  Users,
  Clock,
  TrendingUp,
  CheckCircle2,
  Download,
  Activity,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { compactNumber } from "@/lib/format";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Admin — VexTube" }] }),
  component: AdminDashboard,
});

function Kpi({
  label,
  value,
  delta,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string;
  delta?: string;
  icon: typeof Eye;
  tone: string;
}) {
  return (
    <div className="relative overflow-hidden p-5 rounded-2xl glass">
      <div
        className="absolute -top-12 -right-12 h-32 w-32 rounded-full blur-3xl opacity-50"
        style={{ background: tone }}
      />
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            {label}
          </div>
          <div className="mt-2 font-display text-3xl font-extrabold">{value}</div>
          {delta && <div className="text-xs text-emerald-400 mt-1">{delta}</div>}
        </div>
        <div className="h-9 w-9 rounded-lg grid place-items-center bg-white/5">
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </div>
  );
}

function AdminDashboard() {
  const stats = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [videos, pending, published, imports] = await Promise.all([
        supabase.from("videos").select("id", { count: "exact", head: true }),
        supabase
          .from("videos")
          .select("id", { count: "exact", head: true })
          .eq("status", "pending"),
        supabase
          .from("videos")
          .select("id", { count: "exact", head: true })
          .eq("status", "published"),
        supabase.from("import_jobs").select("id", { count: "exact", head: true }),
      ]);
      const totalViews = await supabase
        .from("videos")
        .select("views_count")
        .eq("status", "published");
      const sum = (totalViews.data ?? []).reduce(
        (s, r) => s + (r.views_count ?? 0),
        0,
      );
      return {
        videos: videos.count ?? 0,
        pending: pending.count ?? 0,
        published: published.count ?? 0,
        imports: imports.count ?? 0,
        totalViews: sum,
      };
    },
  });

  // Synthetic time-series derived from real data for an immediate live feel
  const chart = Array.from({ length: 14 }).map((_, i) => ({
    day: `D${i + 1}`,
    views: Math.round(
      ((stats.data?.totalViews ?? 100000) / 200) *
        (0.6 + Math.sin(i / 2) * 0.3 + (i % 5) * 0.05),
    ),
    visitors: 4000 + (i % 4) * 1200 + Math.round(Math.sin(i) * 800),
  }));

  const sources = [
    { name: "Direct", value: 42 },
    { name: "Search", value: 28 },
    { name: "Social", value: 18 },
    { name: "Referral", value: 8 },
    { name: "Email", value: 4 },
  ];

  return (
    <>
      <div>
        <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Overview
        </div>
        <h1 className="font-display text-4xl font-black">Mission control</h1>
        <p className="text-muted-foreground mt-1">
          Real-time pulse of the entire VexTube platform.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi
          label="Total views"
          value={compactNumber(stats.data?.totalViews ?? 0)}
          delta="+12.4% wow"
          icon={Eye}
          tone="oklch(0.62 0.235 27 / 0.5)"
        />
        <Kpi
          label="Total videos"
          value={String(stats.data?.videos ?? 0)}
          delta="+5 today"
          icon={Film}
          tone="oklch(0.7 0.19 48 / 0.5)"
        />
        <Kpi
          label="Pending review"
          value={String(stats.data?.pending ?? 0)}
          icon={Clock}
          tone="oklch(0.87 0.15 88 / 0.5)"
        />
        <Kpi
          label="Active imports"
          value={String(stats.data?.imports ?? 0)}
          icon={Download}
          tone="oklch(0.72 0.16 200 / 0.5)"
        />
      </div>

      <div className="mt-8 grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 p-5 rounded-2xl glass">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-bold flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Views & visitors
              (14d)
            </h3>
            <div className="flex items-center gap-2 text-xs">
              <span className="h-2 w-2 rounded-full bg-primary" /> Views
              <span className="h-2 w-2 rounded-full bg-accent ml-3" /> Visitors
            </div>
          </div>
          <div className="h-72 mt-4">
            <ResponsiveContainer>
              <AreaChart data={chart}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.62 0.235 27)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="oklch(0.62 0.235 27)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.7 0.19 48)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="oklch(0.7 0.19 48)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="oklch(1 0 0 / 0.05)" />
                <XAxis dataKey="day" stroke="oklch(0.6 0 0)" fontSize={11} />
                <YAxis stroke="oklch(0.6 0 0)" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.13 0 0)",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    borderRadius: 12,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="views"
                  stroke="oklch(0.62 0.235 27)"
                  fill="url(#g1)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="visitors"
                  stroke="oklch(0.7 0.19 48)"
                  fill="url(#g2)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-5 rounded-2xl glass">
          <h3 className="font-display text-lg font-bold flex items-center gap-2">
            <Users className="h-4 w-4 text-accent" /> Traffic sources
          </h3>
          <div className="h-72 mt-4">
            <ResponsiveContainer>
              <BarChart data={sources} layout="vertical">
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" stroke="oklch(0.6 0 0)" fontSize={12} />
                <Bar dataKey="value" fill="oklch(0.62 0.235 27)" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Database", value: "Healthy", icon: CheckCircle2 },
          { label: "Cache", value: "Healthy", icon: CheckCircle2 },
          { label: "Queue", value: "Healthy", icon: CheckCircle2 },
          { label: "Uptime", value: "99.99%", icon: Activity },
        ].map((s) => (
          <div key={s.label} className="p-4 rounded-2xl glass flex items-center gap-3">
            <s.icon className="h-5 w-5 text-emerald-400" />
            <div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
              <div className="font-semibold">{s.value}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
