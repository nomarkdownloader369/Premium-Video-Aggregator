import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageShell } from "@/components/page-shell";
import { Top10Section } from "@/components/top10-section";
import { VideoRow } from "@/components/video-row";
import { publishedVideosQuery } from "@/lib/queries";

export const Route = createFileRoute("/trending")({
  head: () => ({
    meta: [
      { title: "Trending — VexTube" },
      { name: "description", content: "What the world is watching on VexTube." },
    ],
    links: [{ rel: "canonical", href: "/trending" }],
  }),
  component: TrendingPage,
});

function TrendingPage() {
  const trending = useQuery(publishedVideosQuery({ order: "trending", limit: 60 }));
  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px]">
        <div className="text-xs uppercase tracking-[0.3em] text-accent">
          Live signal
        </div>
        <h1 className="font-display text-5xl md:text-6xl font-black">
          Trending <span className="text-gradient-red">now</span>
        </h1>
        <p className="text-muted-foreground mt-2 max-w-xl">
          The cultural pulse. Updated every 30 minutes by VexTube's signal engine.
        </p>
      </div>
      {trending.data && <Top10Section videos={trending.data} />}
      <VideoRow
        title="More trending"
        videos={trending.data?.slice(10, 60) ?? []}
        accent="ember"
      />
    </PageShell>
  );
}
