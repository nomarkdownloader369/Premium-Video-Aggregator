import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { compactNumber, timeAgo, youtubeThumb } from "@/lib/format";
import type { Video } from "@/lib/queries";

export const Route = createFileRoute("/admin/videos")({
  head: () => ({ meta: [{ title: "Videos — VexTube admin" }] }),
  component: VideosAdmin,
});

function VideosAdmin() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | "published" | "pending" | "rejected">(
    "all",
  );
  const { data } = useQuery({
    queryKey: ["admin-videos", filter],
    queryFn: async () => {
      let q = supabase.from("videos").select("*").order("created_at", { ascending: false }).limit(200);
      if (filter !== "all") q = q.eq("status", filter);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Video[];
    },
  });

  const togglePick = async (v: Video) => {
    await supabase
      .from("videos")
      .update({ is_editor_pick: !v.is_editor_pick })
      .eq("id", v.id);
    qc.invalidateQueries({ queryKey: ["admin-videos"] });
  };
  const remove = async (id: string) => {
    if (!confirm("Delete this video?")) return;
    await supabase.from("videos").delete().eq("id", id);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["admin-videos"] });
  };

  return (
    <>
      <div className="flex items-end justify-between flex-wrap gap-4">
        <h1 className="font-display text-4xl font-black">All videos</h1>
        <div className="flex gap-2">
          {(["all", "published", "pending", "rejected"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs uppercase tracking-wider ${
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "bg-white/5 text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-6 overflow-hidden rounded-2xl glass">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase tracking-wider text-muted-foreground bg-white/5">
            <tr>
              <th className="text-left p-4">Video</th>
              <th className="text-left p-4">Status</th>
              <th className="text-left p-4">Views</th>
              <th className="text-left p-4">Created</th>
              <th className="text-right p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(data ?? []).map((v) => (
              <tr key={v.id} className="border-t border-white/5">
                <td className="p-3">
                  <div className="flex gap-3 items-center">
                    <img
                      src={v.thumbnail_url || youtubeThumb(v.youtube_id, "hq")}
                      className="w-20 aspect-video object-cover rounded-md"
                      alt=""
                    />
                    <div className="min-w-0">
                      <div className="font-semibold line-clamp-1">{v.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {v.youtube_id}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="p-3">
                  <span
                    className={`text-xs uppercase tracking-wider px-2 py-1 rounded ${
                      v.status === "published"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : v.status === "pending"
                          ? "bg-gold/20 text-gold"
                          : "bg-primary/20 text-primary"
                    }`}
                  >
                    {v.status}
                  </span>
                </td>
                <td className="p-3">{compactNumber(v.views_count)}</td>
                <td className="p-3 text-muted-foreground">{timeAgo(v.created_at)}</td>
                <td className="p-3 text-right">
                  <button
                    onClick={() => togglePick(v)}
                    className={`inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs mr-1 ${
                      v.is_editor_pick
                        ? "bg-gold/20 text-gold"
                        : "bg-white/5 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Star className="h-3 w-3" /> Pick
                  </button>
                  <button
                    onClick={() => remove(v.id)}
                    className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs bg-primary/20 text-primary"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
