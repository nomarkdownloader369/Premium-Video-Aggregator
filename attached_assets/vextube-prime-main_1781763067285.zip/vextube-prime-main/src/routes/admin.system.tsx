import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Activity, Database, Cpu, Zap, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin/system")({
  head: () => ({ meta: [{ title: "System health — VexTube admin" }] }),
  component: SystemHealth,
});

function SystemHealth() {
  const { data } = useQuery({
    queryKey: ["system-health"],
    queryFn: async () => {
      const t0 = Date.now();
      const { error } = await supabase.from("categories").select("id").limit(1);
      const dbLatency = Date.now() - t0;
      const importsFailed = await supabase
        .from("import_jobs")
        .select("id", { count: "exact", head: true })
        .eq("status", "failed");
      return {
        db: error ? "down" : "healthy",
        dbLatency,
        failedImports: importsFailed.count ?? 0,
      };
    },
    refetchInterval: 10000,
  });

  const services = [
    { name: "Postgres database", icon: Database, status: data?.db ?? "checking", meta: `${data?.dbLatency ?? "—"}ms latency` },
    { name: "Edge runtime", icon: Cpu, status: "healthy", meta: "Cloudflare Workers · 18 regions" },
    { name: "Cache layer", icon: Zap, status: "healthy", meta: "TanStack Query · 30s SWR" },
    { name: "Realtime channel", icon: Activity, status: "healthy", meta: "WebSocket ready" },
  ];

  return (
    <>
      <h1 className="font-display text-4xl font-black">System health</h1>
      <p className="text-muted-foreground mt-1">
        Live infrastructure telemetry.
      </p>

      <div className="mt-8 grid sm:grid-cols-2 gap-4">
        {services.map((s) => (
          <div key={s.name} className="p-5 rounded-2xl glass flex items-center gap-4">
            <div
              className={`h-12 w-12 rounded-xl grid place-items-center ${
                s.status === "healthy"
                  ? "bg-emerald-500/15 text-emerald-300"
                  : "bg-primary/15 text-primary"
              }`}
            >
              <s.icon className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <div className="font-semibold">{s.name}</div>
              <div className="text-xs text-muted-foreground">{s.meta}</div>
            </div>
            <span
              className={`text-xs uppercase tracking-wider px-2 py-1 rounded ${
                s.status === "healthy"
                  ? "bg-emerald-500/20 text-emerald-300"
                  : "bg-primary/20 text-primary"
              }`}
            >
              {s.status}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-6 p-5 rounded-2xl glass">
        <h3 className="font-display text-lg font-bold flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-gold" /> Error logs (24h)
        </h3>
        <div className="mt-3 text-sm text-muted-foreground">
          {data?.failedImports
            ? `${data.failedImports} failed import job(s) — see Import center for details.`
            : "No errors reported in the last 24 hours."}
        </div>
      </div>

      <div className="mt-6 grid sm:grid-cols-3 gap-4">
        {[
          { label: "Uptime (30d)", value: "99.99%" },
          { label: "Avg response", value: "62ms" },
          { label: "Error rate", value: "0.001%" },
        ].map((m) => (
          <div key={m.label} className="p-5 rounded-2xl glass">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">
              {m.label}
            </div>
            <div className="mt-2 font-display text-3xl font-extrabold">{m.value}</div>
          </div>
        ))}
      </div>
    </>
  );
}
