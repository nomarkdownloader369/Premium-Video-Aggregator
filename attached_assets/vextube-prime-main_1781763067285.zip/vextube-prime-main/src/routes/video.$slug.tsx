import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Eye, ThumbsUp, Share2, Bookmark, Flame } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { VideoRow } from "@/components/video-row";
import { publishedVideosQuery, videoBySlugQuery } from "@/lib/queries";
import { compactNumber, timeAgo } from "@/lib/format";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/video/$slug")({
  head: () => ({
    meta: [
      { title: "Video — VexTube" },
      { property: "og:type", content: "video.other" },
    ],
  }),
  component: VideoPage,
});

function VideoPage() {
  const { slug } = Route.useParams();
  const { data: video, isLoading } = useQuery(videoBySlugQuery(slug));
  const related = useQuery(
    publishedVideosQuery({
      categoryId: video?.category_id ?? undefined,
      order: "trending",
      limit: 12,
    }),
  );

  useEffect(() => {
    if (video?.id) {
      supabase.rpc("increment_view", { _video_id: video.id });
      supabase.from("video_views").insert({
        video_id: video.id,
        session_id:
          typeof window !== "undefined" ? localStorage.getItem("vt_sid") ?? null : null,
        referrer: typeof document !== "undefined" ? document.referrer : null,
      });
    }
  }, [video?.id]);

  if (isLoading) {
    return (
      <PageShell>
        <div className="container-px mx-auto max-w-[1600px]">
          <div className="aspect-video rounded-2xl shimmer" />
        </div>
      </PageShell>
    );
  }

  if (!video) {
    return (
      <PageShell>
        <div className="container-px mx-auto max-w-[1600px] py-24 text-center">
          <h1 className="text-3xl font-bold">Video not found</h1>
          <p className="text-muted-foreground mt-2">
            It may have been removed or is awaiting review.
          </p>
          <Link
            to="/"
            className="inline-flex mt-6 px-5 py-2.5 rounded-full bg-primary text-primary-foreground font-semibold"
          >
            Back home
          </Link>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px] grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="relative aspect-video overflow-hidden rounded-2xl border border-white/5 bg-black shadow-card">
            <iframe
              className="absolute inset-0 h-full w-full"
              src={`https://www.youtube.com/embed/${video.youtube_id}?autoplay=1&rel=0&modestbranding=1`}
              title={video.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
          <h1 className="mt-5 font-display text-2xl md:text-3xl font-extrabold tracking-tight">
            {video.title}
          </h1>
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Eye className="h-4 w-4" /> {compactNumber(video.views_count)} views
            </span>
            <span>·</span>
            <span>{timeAgo(video.published_at ?? video.created_at)}</span>
            {video.is_editor_pick && (
              <>
                <span>·</span>
                <span className="inline-flex items-center gap-1 text-gold">
                  <Flame className="h-3 w-3" /> Editor pick
                </span>
              </>
            )}
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <button className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-sm">
              <ThumbsUp className="h-4 w-4" /> {compactNumber(video.likes_count)}
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-sm">
              <Share2 className="h-4 w-4" /> Share
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-sm">
              <Bookmark className="h-4 w-4" /> Save
            </button>
          </div>

          <div className="mt-6 p-5 rounded-2xl glass">
            <p className="text-sm whitespace-pre-wrap text-muted-foreground">
              {video.description || "No description provided."}
            </p>
            {video.tags?.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {video.tags.map((t) => (
                  <span
                    key={t}
                    className="text-xs px-2.5 py-1 rounded-full bg-white/5 border border-white/10"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        <aside className="space-y-3">
          <h3 className="font-display text-lg font-bold">Up next</h3>
          {(related.data ?? []).filter((r) => r.id !== video.id).slice(0, 8).map((r) => (
            <Link
              key={r.id}
              to="/video/$slug"
              params={{ slug: r.slug }}
              className="flex gap-3 group"
            >
              <div className="relative w-40 aspect-video rounded-lg overflow-hidden flex-shrink-0">
                <img
                  src={r.thumbnail_url ?? ""}
                  alt={r.title}
                  className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition"
                />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold line-clamp-2 group-hover:text-primary transition">
                  {r.title}
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {compactNumber(r.views_count)} views · {timeAgo(r.published_at)}
                </div>
              </div>
            </Link>
          ))}
        </aside>
      </div>

      <VideoRow
        title="More like this"
        videos={(related.data ?? []).filter((r) => r.id !== video.id).slice(0, 10)}
        accent="red"
      />
    </PageShell>
  );
}
