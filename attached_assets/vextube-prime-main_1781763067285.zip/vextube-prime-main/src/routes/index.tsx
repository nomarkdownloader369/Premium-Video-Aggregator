import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageShell } from "@/components/page-shell";
import { HeroSection } from "@/components/hero-section";
import { Top10Section } from "@/components/top10-section";
import { VideoRow } from "@/components/video-row";
import { CategoryStrip } from "@/components/category-strip";
import {
  categoriesQuery,
  publishedVideosQuery,
} from "@/lib/queries";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VexTube — Cinematic streaming, reimagined" },
      {
        name: "description",
        content:
          "Discover trending, top 5, editor picks, and category-curated cinematic videos on VexTube.",
      },
      { property: "og:title", content: "VexTube — Cinematic streaming" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  const cats = useQuery(categoriesQuery());
  const trending = useQuery(publishedVideosQuery({ order: "trending", limit: 24 }));
  const recent = useQuery(publishedVideosQuery({ order: "recent", limit: 10 }));
  const mostViewed = useQuery(publishedVideosQuery({ order: "views", limit: 10 }));
  const picks = useQuery(publishedVideosQuery({ editorPick: true, limit: 10 }));

  const heroSlides = trending.data ?? [];
  // synthesize "today / week / month" by re-slicing the views-sorted list
  const today = mostViewed.data?.slice(0, 10) ?? [];
  const week = mostViewed.data?.slice(2, 12) ?? mostViewed.data ?? [];
  const month = [...(mostViewed.data ?? [])].reverse().slice(0, 10);
  const recommended = trending.data?.slice(4, 14) ?? [];

  return (
    <PageShell noPadding>
      {heroSlides.length ? (
        <HeroSection videos={heroSlides} />
      ) : (
        <div className="min-h-[80vh] grid place-items-center">
          <div className="text-center">
            <div className="inline-flex h-12 w-12 mb-4 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
            <div className="text-muted-foreground text-sm">Loading cinematic experience…</div>
          </div>
        </div>
      )}

      {trending.data && <Top10Section videos={trending.data} />}

      <VideoRow
        eyebrow="Live signal"
        title="Trending now"
        subtitle="What the world is watching right now"
        videos={trending.data?.slice(0, 10) ?? []}
        href="/trending"
        accent="red"
      />
      <VideoRow
        eyebrow="Curated"
        title="Editor picks"
        subtitle="Hand-selected by the VexTube taste team"
        videos={picks.data ?? []}
        accent="gold"
      />
      <VideoRow
        eyebrow="Today"
        title="Most viewed today"
        subtitle="The signal cuts through the noise"
        videos={today}
        accent="ember"
      />
      <VideoRow
        eyebrow="This week"
        title="Top this week"
        subtitle="Seven days of momentum"
        videos={week}
        accent="red"
      />
      <VideoRow
        eyebrow="For you"
        title="Recommended for you"
        subtitle="Tuned to your taste graph"
        videos={recommended}
        accent="ice"
      />
      <VideoRow
        eyebrow="This month"
        title="Top of the month"
        subtitle="A month of cinematic highs"
        videos={month}
        accent="gold"
      />
      <VideoRow
        eyebrow="Fresh"
        title="Latest uploads"
        subtitle="Straight from the pipeline"
        videos={recent.data ?? []}
        accent="ice"
      />

      {cats.data && <CategoryStrip categories={cats.data} />}

      <div className="h-24" />
    </PageShell>
  );
}
