import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Upload, BarChart3, Bell, Settings, Eye, Clock } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { VideoCard } from "@/components/video-card";
import { supabase } from "@/integrations/supabase/client";
import { compactNumber } from "@/lib/format";
import type { Video } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — VexTube" }] }),
  component: Dashboard,
});

function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  hint?: string;
  icon: typeof Eye;
  accent: string;
}) {
  return (
    <div className="relative overflow-hidden p-6 rounded-2xl glass">
      <div
        className="absolute inset-x-0 -top-20 h-32 blur-3xl opacity-40"
        style={{ background: accent }}
      />
      <div className="relative flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            {label}
          </div>
          <div className="mt-2 font-display text-3xl font-extrabold">{value}</div>
          {hint && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
        </div>
        <div className="h-10 w-10 rounded-full grid place-items-center bg-white/5">
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function Dashboard() {
  const [userId, setUserId] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const myVideos = useQuery({
    queryKey: ["my-videos", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("submitter_id", userId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Video[];
    },
  });

  const totalViews = (myVideos.data ?? []).reduce((s, v) => s + v.views_count, 0);
  const published = (myVideos.data ?? []).filter((v) => v.status === "published")
    .length;
  const pending = (myVideos.data ?? []).filter((v) => v.status === "pending").length;

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-[1600px]">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              Creator
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-black">
              Your <span className="text-gradient-red">dashboard</span>
            </h1>
          </div>
          <Link
            to="/submit"
            className="inline-flex items-center gap-2 h-11 px-5 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow"
          >
            <Upload className="h-4 w-4" /> Submit a video
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            label="Total views"
            value={compactNumber(totalViews)}
            hint="Across all videos"
            icon={Eye}
            accent="oklch(0.62 0.235 27 / 0.5)"
          />
          <StatCard
            label="Published"
            value={String(published)}
            hint="Live on VexTube"
            icon={BarChart3}
            accent="oklch(0.7 0.19 48 / 0.5)"
          />
          <StatCard
            label="Pending review"
            value={String(pending)}
            hint="Awaiting moderation"
            icon={Clock}
            accent="oklch(0.87 0.15 88 / 0.5)"
          />
          <StatCard
            label="Notifications"
            value="3"
            hint="Updates this week"
            icon={Bell}
            accent="oklch(0.72 0.16 200 / 0.5)"
          />
        </div>

        <div className="mt-12">
          <h2 className="font-display text-2xl font-extrabold">Your videos</h2>
          {myVideos.data && myVideos.data.length === 0 && (
            <div className="mt-6 p-12 text-center rounded-2xl glass">
              <p className="text-muted-foreground">You haven't submitted any videos yet.</p>
              <Link
                to="/submit"
                className="inline-flex mt-4 px-5 py-2.5 rounded-full bg-primary text-primary-foreground font-semibold"
              >
                Submit your first
              </Link>
            </div>
          )}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
            {(myVideos.data ?? []).map((v) => (
              <div key={v.id} className="relative">
                <VideoCard video={v} />
                <span
                  className={`absolute top-2 right-2 text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-md ${
                    v.status === "published"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : v.status === "pending"
                        ? "bg-gold/20 text-gold border border-gold/30"
                        : "bg-primary/20 text-primary border border-primary/30"
                  }`}
                >
                  {v.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageShell>
  );
}
