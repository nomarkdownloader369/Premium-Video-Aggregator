import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageShell } from "@/components/page-shell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — VexTube" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUserId(data.user.id);
      setEmail(data.user.email ?? "");
      const { data: p } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", data.user.id)
        .maybeSingle();
      if (p) {
        setDisplayName(p.display_name ?? "");
        setBio(p.bio ?? "");
      }
    });
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId) return;
    setLoading(true);
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName, bio })
      .eq("id", userId);
    setLoading(false);
    if (error) toast.error(error.message);
    else toast.success("Settings saved");
  };

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-2xl">
        <h1 className="font-display text-4xl font-black">Account settings</h1>
        <form onSubmit={save} className="mt-8 space-y-5">
          <div>
            <label className="text-sm font-semibold">Email</label>
            <input
              value={email}
              disabled
              className="mt-2 w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 text-muted-foreground"
            />
          </div>
          <div>
            <label className="text-sm font-semibold">Display name</label>
            <input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={60}
              className="mt-2 w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div>
            <label className="text-sm font-semibold">Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={4}
              maxLength={500}
              className="mt-2 w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>
          <button
            disabled={loading}
            className="h-11 px-6 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow disabled:opacity-60"
          >
            {loading ? "Saving…" : "Save changes"}
          </button>
        </form>
      </div>
    </PageShell>
  );
}
