import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCircle2 } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { supabase } from "@/integrations/supabase/client";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — VexTube" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  const markAll = async () => {
    await supabase
      .from("notifications")
      .update({ is_read: true })
      .eq("is_read", false);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-3xl">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-4xl font-black flex items-center gap-3">
            <Bell className="h-7 w-7 text-primary" /> Notifications
          </h1>
          <button
            onClick={markAll}
            className="text-sm px-4 py-2 rounded-full bg-white/5 hover:bg-white/10"
          >
            Mark all as read
          </button>
        </div>
        <div className="mt-8 space-y-3">
          {(data ?? []).length === 0 && (
            <div className="p-10 rounded-2xl glass text-center text-muted-foreground">
              You're all caught up.
            </div>
          )}
          {(data ?? []).map((n) => (
            <div
              key={n.id}
              className={`p-5 rounded-2xl border ${
                n.is_read
                  ? "border-white/5 bg-white/[0.02]"
                  : "border-primary/30 bg-primary/[0.06]"
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-full grid place-items-center bg-gradient-to-br from-primary to-accent">
                  <Bell className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-wider text-muted-foreground">
                      {n.type}
                    </span>
                    {!n.is_read && (
                      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    )}
                  </div>
                  <div className="font-semibold mt-1">{n.title}</div>
                  {n.body && (
                    <div className="text-sm text-muted-foreground mt-1">
                      {n.body}
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground mt-2">
                    {timeAgo(n.created_at)}
                  </div>
                </div>
                {n.is_read && (
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  );
}
