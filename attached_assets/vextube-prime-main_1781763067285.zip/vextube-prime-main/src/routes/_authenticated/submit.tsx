import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Upload, Link2 } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { supabase } from "@/integrations/supabase/client";
import { categoriesQuery } from "@/lib/queries";
import { youtubeThumb } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/submit")({
  head: () => ({ meta: [{ title: "Submit a video — VexTube" }] }),
  component: SubmitPage,
});

function parseYoutube(input: string): string | null {
  if (!input) return null;
  const m =
    input.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/) ||
    input.match(/^([A-Za-z0-9_-]{11})$/);
  return m ? m[1] : null;
}

function slugify(t: string) {
  return t
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 80) + "-" + Math.random().toString(36).slice(2, 8);
}

function SubmitPage() {
  const navigate = useNavigate();
  const cats = useQuery(categoriesQuery());
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [loading, setLoading] = useState(false);

  const yt = parseYoutube(url);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!yt) {
      toast.error("Please paste a valid YouTube URL");
      return;
    }
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    setLoading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("videos").insert({
        slug: slugify(title),
        title: title.trim(),
        description: description.trim() || null,
        youtube_id: yt,
        thumbnail_url: youtubeThumb(yt),
        category_id: categoryId || null,
        submitter_id: u.user?.id,
        status: "pending",
        tags: tags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
      });
      if (error) throw error;
      toast.success("Submitted! Awaiting moderation.");
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Submission failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell>
      <div className="container-px mx-auto max-w-3xl">
        <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Creators
        </div>
        <h1 className="font-display text-4xl md:text-5xl font-black">
          Submit a <span className="text-gradient-red">video</span>
        </h1>
        <p className="text-muted-foreground mt-2">
          Paste a YouTube URL. Our moderators will review it within minutes.
        </p>

        <form onSubmit={submit} className="mt-10 space-y-6">
          <div>
            <label className="text-sm font-semibold flex items-center gap-2">
              <Link2 className="h-4 w-4 text-primary" /> YouTube URL
            </label>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=…"
              className="mt-2 w-full h-12 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring"
            />
            {yt && (
              <div className="mt-3 flex items-center gap-3 p-3 rounded-xl glass">
                <img
                  src={youtubeThumb(yt, "hq")}
                  className="h-16 w-28 object-cover rounded-md"
                  alt=""
                />
                <div className="text-xs text-muted-foreground">
                  YouTube ID detected · <span className="text-foreground">{yt}</span>
                </div>
              </div>
            )}
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold">Title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={200}
                className="mt-2 w-full h-12 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div>
              <label className="text-sm font-semibold">Category</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="mt-2 w-full h-12 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="">Uncategorized</option>
                {cats.data?.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              maxLength={2000}
              className="mt-2 w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
          </div>

          <div>
            <label className="text-sm font-semibold">Tags (comma separated)</label>
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="cinematic, trailer, scifi"
              className="mt-2 w-full h-12 px-4 rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          <button
            disabled={loading}
            className="inline-flex items-center gap-2 h-12 px-7 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow disabled:opacity-60"
          >
            <Upload className="h-4 w-4" /> {loading ? "Submitting…" : "Submit for review"}
          </button>
        </form>
      </div>
    </PageShell>
  );
}
