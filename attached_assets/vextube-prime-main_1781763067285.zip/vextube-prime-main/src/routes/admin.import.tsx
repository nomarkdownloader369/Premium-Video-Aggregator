import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Play, Pause, Trash2, RefreshCcw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/admin/import")({
  head: () => ({ meta: [{ title: "Import center — VexTube admin" }] }),
  component: ImportCenter,
});

function ImportCenter() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    source: "youtube_search",
    query: "",
    channel_id: "",
    schedule_cron: "*/30 * * * *",
  });
  const { data } = useQuery({
    queryKey: ["import-jobs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("import_jobs")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("import_jobs").insert({
      source: form.source,
      query: form.query || null,
      channel_id: form.channel_id || null,
      schedule_cron: form.schedule_cron,
      status: "queued",
      next_run_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    });
    if (error) return toast.error(error.message);
    toast.success("Import job created");
    setOpen(false);
    setForm({ source: "youtube_search", query: "", channel_id: "", schedule_cron: "*/30 * * * *" });
    qc.invalidateQueries({ queryKey: ["import-jobs"] });
  };

  const toggle = async (id: string, enabled: boolean) => {
    await supabase.from("import_jobs").update({ enabled: !enabled }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["import-jobs"] });
  };
  const remove = async (id: string) => {
    await supabase.from("import_jobs").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["import-jobs"] });
  };
  const runNow = async (id: string) => {
    await supabase
      .from("import_jobs")
      .update({ status: "running", last_run_at: new Date().toISOString() })
      .eq("id", id);
    toast.success("Job queued for immediate run");
    qc.invalidateQueries({ queryKey: ["import-jobs"] });
  };

  return (
    <>
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-display text-4xl font-black">Import center</h1>
          <p className="text-muted-foreground mt-1">
            Schedule automatic discovery from any source.
          </p>
        </div>
        <button
          onClick={() => setOpen(!open)}
          className="inline-flex items-center gap-2 h-10 px-4 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-glow"
        >
          <Plus className="h-4 w-4" /> New import job
        </button>
      </div>

      {open && (
        <form
          onSubmit={create}
          className="mt-6 p-5 rounded-2xl glass grid sm:grid-cols-2 gap-3"
        >
          <select
            value={form.source}
            onChange={(e) => setForm({ ...form, source: e.target.value })}
            className="h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-sm"
          >
            <option value="youtube_search">YouTube search</option>
            <option value="youtube_channel">YouTube channel</option>
            <option value="youtube_keyword">Keyword feed</option>
            <option value="custom_api">Custom provider (future)</option>
          </select>
          <input
            value={form.schedule_cron}
            onChange={(e) => setForm({ ...form, schedule_cron: e.target.value })}
            placeholder="Cron schedule"
            className="h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-sm font-mono"
          />
          <input
            value={form.query}
            onChange={(e) => setForm({ ...form, query: e.target.value })}
            placeholder="Search query (e.g. cinematic trailers)"
            className="h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-sm"
          />
          <input
            value={form.channel_id}
            onChange={(e) => setForm({ ...form, channel_id: e.target.value })}
            placeholder="Channel ID (optional)"
            className="h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-sm"
          />
          <button className="sm:col-span-2 h-10 rounded-full bg-primary text-primary-foreground font-semibold">
            Create job
          </button>
        </form>
      )}

      <div className="mt-6 overflow-hidden rounded-2xl glass">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase tracking-wider text-muted-foreground bg-white/5">
            <tr>
              <th className="text-left p-3">Source</th>
              <th className="text-left p-3">Query / Channel</th>
              <th className="text-left p-3">Schedule</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Imported</th>
              <th className="text-left p-3">Last run</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(data ?? []).map((j) => (
              <tr key={j.id} className="border-t border-white/5">
                <td className="p-3 font-mono text-xs">{j.source}</td>
                <td className="p-3">{j.query || j.channel_id || "—"}</td>
                <td className="p-3 font-mono text-xs text-muted-foreground">
                  {j.schedule_cron}
                </td>
                <td className="p-3">
                  <span
                    className={`text-xs uppercase tracking-wider px-2 py-1 rounded ${
                      j.status === "success"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : j.status === "running"
                          ? "bg-accent/20 text-accent"
                          : j.status === "failed"
                            ? "bg-primary/20 text-primary"
                            : "bg-gold/20 text-gold"
                    }`}
                  >
                    {j.status}
                  </span>
                </td>
                <td className="p-3">{j.items_imported}</td>
                <td className="p-3 text-muted-foreground">
                  {j.last_run_at ? timeAgo(j.last_run_at) : "never"}
                </td>
                <td className="p-3 text-right space-x-1">
                  <button
                    onClick={() => runNow(j.id)}
                    className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs bg-white/5 hover:bg-white/10"
                  >
                    <RefreshCcw className="h-3 w-3" /> Run
                  </button>
                  <button
                    onClick={() => toggle(j.id, j.enabled)}
                    className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs bg-white/5 hover:bg-white/10"
                  >
                    {j.enabled ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                  </button>
                  <button
                    onClick={() => remove(j.id)}
                    className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs bg-primary/20 text-primary"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
