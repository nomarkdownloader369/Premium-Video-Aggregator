import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { TrendingUp, ArrowUp, ArrowDown, Minus, Play } from "lucide-react";
import type { Video } from "@/lib/queries";
import { compactNumber, youtubeThumb } from "@/lib/format";

export function Top10Section({ videos }: { videos: Video[] }) {
  const top = videos.slice(0, 5);
  if (!top.length) return null;
  return (
    <section className="container-px mx-auto max-w-[1600px] mt-24 md:mt-28">
      <div className="flex items-end justify-between mb-8 gap-6">
        <div>
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-gold/80 font-bold mb-3">
            <span className="h-px w-8 bg-gold/60" /> Signal Engine
          </div>
          <motion.h2
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl md:text-6xl font-black tracking-tighter leading-none"
          >
            Top <span className="text-gradient-gold">5</span> trending
          </motion.h2>
          <p className="text-sm text-muted-foreground mt-3 flex items-center gap-2">
            <TrendingUp className="h-3.5 w-3.5 text-accent" />
            Refreshed every 30 minutes · ranked by global viewership velocity
          </p>
        </div>
        <Link to="/trending" className="hidden md:inline-flex text-sm text-muted-foreground hover:text-foreground transition story-link">
          View full chart →
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 md:gap-5">
        {top.map((v, i) => {
          const movement = [(i + 1) * 3 - 5, 1, -2, 4, 0][i] ?? 0;
          return (
            <motion.div
              key={v.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.06, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            >
              <Link
                to="/video/$slug"
                params={{ slug: v.slug }}
                className="group relative block aspect-[3/4] rounded-3xl overflow-hidden bg-card border border-white/5 hover:border-primary/40 transition"
              >
                <img
                  src={v.thumbnail_url || youtubeThumb(v.youtube_id, "max")}
                  alt={v.title}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition duration-[1200ms] group-hover:scale-110"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = youtubeThumb(v.youtube_id, "hq");
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-transparent to-accent/20 opacity-0 group-hover:opacity-100 transition duration-500" />

                {/* Massive outlined rank numeral */}
                <span
                  className="absolute -left-3 -bottom-8 font-display font-black leading-none text-[180px] md:text-[220px] select-none pointer-events-none"
                  style={{
                    WebkitTextStroke: "2.5px oklch(0.62 0.235 27)",
                    color: "transparent",
                    textShadow:
                      "0 30px 80px oklch(0.62 0.235 27 / 0.5), 0 0 60px oklch(0.7 0.19 48 / 0.3)",
                  }}
                >
                  {i + 1}
                </span>

                {/* Movement chip */}
                <div className="absolute top-3 right-3 flex items-center gap-1 text-[10px] font-bold uppercase glass px-2.5 py-1 rounded-full">
                  {movement > 0 ? (
                    <ArrowUp className="h-3 w-3 text-emerald-400" />
                  ) : movement < 0 ? (
                    <ArrowDown className="h-3 w-3 text-primary" />
                  ) : (
                    <Minus className="h-3 w-3 text-muted-foreground" />
                  )}
                  <span>{Math.abs(movement) || "—"}</span>
                </div>

                {/* Hover play */}
                <div className="absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition">
                  <div className="h-16 w-16 rounded-full bg-primary/95 grid place-items-center shadow-glow">
                    <Play className="h-6 w-6 fill-current ml-0.5" />
                  </div>
                </div>

                {/* Bottom meta */}
                <div className="absolute left-5 right-5 bottom-5">
                  <div className="text-[10px] uppercase tracking-[0.25em] text-gold font-bold mb-1.5">
                    Viral · #{i + 1}
                  </div>
                  <div className="text-base font-bold leading-tight line-clamp-2 drop-shadow">
                    {v.title}
                  </div>
                  <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">{compactNumber(v.views_count)}</span>
                    <span>views</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground/60" />
                    <span className="text-accent font-semibold">{compactNumber(Math.round(v.trending_score))}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
