import { ChevronRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import type { Video } from "@/lib/queries";
import { VideoCard } from "./video-card";

export function VideoRow({
  title,
  subtitle,
  videos,
  href,
  accent,
  eyebrow,
}: {
  title: string;
  subtitle?: string;
  videos: Video[];
  href?: string;
  accent?: "red" | "gold" | "ember" | "ice";
  eyebrow?: string;
}) {
  if (!videos.length) return null;
  const accentClass =
    accent === "gold"
      ? "text-gradient-gold"
      : accent === "ember"
        ? "text-accent"
        : accent === "ice"
          ? "text-foreground"
          : "text-gradient-red";
  const eyebrowColor =
    accent === "gold"
      ? "text-gold/80"
      : accent === "ember"
        ? "text-accent/80"
        : accent === "ice"
          ? "text-muted-foreground"
          : "text-primary/80";

  return (
    <section className="container-px mx-auto max-w-[1600px] mt-16 md:mt-20">
      <div className="flex items-end justify-between mb-6 gap-6">
        <div>
          {eyebrow && (
            <div className={`inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] font-bold mb-2 ${eyebrowColor}`}>
              <span className="h-px w-6 bg-current opacity-60" /> {eyebrow}
            </div>
          )}
          <motion.h2
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            className="font-display text-2xl md:text-4xl font-black tracking-tighter leading-tight"
          >
            <span className={accentClass}>{title.split(" ")[0]}</span>{" "}
            <span className="text-foreground">{title.split(" ").slice(1).join(" ")}</span>
          </motion.h2>
          {subtitle && (
            <p className="text-sm text-muted-foreground mt-1.5">{subtitle}</p>
          )}
        </div>
        {href && (
          <Link
            to={href}
            className="hidden sm:inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition group"
          >
            See all
            <ChevronRight className="h-4 w-4 group-hover:translate-x-0.5 transition" />
          </Link>
        )}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-5">
        {videos.map((v) => (
          <VideoCard key={v.id} video={v} />
        ))}
      </div>
    </section>
  );
}
