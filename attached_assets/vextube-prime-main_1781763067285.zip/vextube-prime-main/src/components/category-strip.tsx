import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import type { Category } from "@/lib/queries";

export function CategoryStrip({ categories }: { categories: Category[] }) {
  if (!categories.length) return null;
  return (
    <section className="container-px mx-auto max-w-[1600px] mt-16">
      <motion.h2
        initial={{ opacity: 0, y: 8 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-display text-2xl md:text-3xl font-extrabold mb-5"
      >
        Explore by <span className="text-gradient-red">category</span>
      </motion.h2>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {categories.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.03 }}
          >
            <Link
              to="/category/$slug"
              params={{ slug: c.slug }}
              className="group relative block aspect-[4/3] rounded-2xl border border-white/5 overflow-hidden"
              style={{
                background: `linear-gradient(135deg, ${c.color ?? "#E50914"}33, transparent)`,
              }}
            >
              <div className="absolute inset-0 grid place-items-center">
                <div
                  className="h-12 w-12 rounded-full grid place-items-center text-2xl font-black"
                  style={{ background: c.color ?? "#E50914", color: "white" }}
                >
                  {c.name[0]}
                </div>
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-sm font-semibold">
                {c.name}
              </div>
              <div className="absolute inset-0 ring-0 ring-primary/0 group-hover:ring-2 group-hover:ring-primary/60 transition" />
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
