import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-32 border-t border-white/5">
      <div className="container-px mx-auto max-w-[1600px] py-16 grid gap-12 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-accent" />
            <span className="font-display text-xl font-extrabold">
              Vex<span className="text-gradient-red">Tube</span>
            </span>
          </div>
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            A cinematic streaming platform engineered for discovery. Built with
            obsession over latency, taste and motion.
          </p>
        </div>
        {[
          {
            title: "Discover",
            links: [
              { label: "Home", to: "/" },
              { label: "Trending", to: "/trending" },
              { label: "Categories", to: "/categories" },
            ],
          },
          {
            title: "Creators",
            links: [
              { label: "Submit a video", to: "/submit" },
              { label: "Dashboard", to: "/dashboard" },
              { label: "Settings", to: "/settings" },
            ],
          },
          {
            title: "Platform",
            links: [
              { label: "Admin", to: "/admin" },
              { label: "Import center", to: "/admin/import" },
              { label: "Analytics", to: "/admin/analytics" },
            ],
          },
        ].map((col) => (
          <div key={col.title}>
            <h4 className="text-sm font-semibold mb-3">{col.title}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {col.links.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="hover:text-foreground transition">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/5">
        <div className="container-px mx-auto max-w-[1600px] py-6 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} VexTube. All rights reserved.</span>
          <span>Crafted with obsession. Powered by Lovable Cloud.</span>
        </div>
      </div>
    </footer>
  );
}
