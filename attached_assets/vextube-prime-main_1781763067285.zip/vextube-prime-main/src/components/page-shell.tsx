import type { ReactNode } from "react";
import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { Toaster } from "@/components/ui/sonner";

export function PageShell({
  children,
  noPadding,
}: {
  children: ReactNode;
  noPadding?: boolean;
}) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SiteHeader />
      <main className={`flex-1 ${noPadding ? "" : "pt-20"}`}>{children}</main>
      <SiteFooter />
      <Toaster position="bottom-right" theme="dark" />
    </div>
  );
}
