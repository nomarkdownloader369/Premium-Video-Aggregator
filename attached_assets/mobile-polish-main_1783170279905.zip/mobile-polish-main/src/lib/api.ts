// Unified mock API service. Swap BASE with your Replit backend URL when ready.
// All functions mirror standard REST endpoints so wiring becomes a one-line change.
import { VIDEOS, STUDIOS, PORNSTARS, CATEGORIES, type Video, type Pornstar } from "./videos";

export const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? "/api";

export type ListParams = {
  page?: number;
  limit?: number;
  sort?: "new" | "top" | "views";
  category?: string;
  studio?: string;
  pornstar?: string;
  q?: string;
};

function qs(params: Record<string, unknown>) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v != null && v !== "") p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : "";
}

function filterVideos(params: ListParams): Video[] {
  let list = [...VIDEOS];
  if (params.studio) list = list.filter((v) => v.studio.toLowerCase() === params.studio!.toLowerCase());
  if (params.pornstar) list = list.filter((v) => v.stars.some((s) => s.toLowerCase().includes(params.pornstar!.toLowerCase())));
  if (params.category) list = list.filter((v) => v.tags.includes(params.category!.toLowerCase()) || v.title.toLowerCase().includes(params.category!.toLowerCase()));
  if (params.q) list = list.filter((v) => v.title.toLowerCase().includes(params.q!.toLowerCase()));
  if (params.sort === "views") list.sort((a, b) => parseFloat(b.views) - parseFloat(a.views));
  const page = params.page ?? 1;
  const limit = params.limit ?? 24;
  return list.slice((page - 1) * limit, page * limit);
}

// In production, replace bodies with fetch(`${API_BASE}/...${qs(params)}`).then(r=>r.json())
export const api = {
  endpoint: (path: string, params: ListParams = {}) => `${API_BASE}${path}${qs(params)}`,

  listVideos: async (params: ListParams = {}): Promise<Video[]> => filterVideos(params),
  getVideo: async (slug: string): Promise<Video | undefined> => VIDEOS.find((v) => v.slug === slug),
  listStudios: async (): Promise<string[]> => STUDIOS,
  listPornstars: async (): Promise<Pornstar[]> => PORNSTARS,
  listCategories: async (): Promise<string[]> => CATEGORIES,
  search: async (q: string, params: ListParams = {}): Promise<Video[]> => filterVideos({ ...params, q }),
};
